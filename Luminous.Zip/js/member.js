function check_input() {
	console.log('check_input()');
	document.member_form.submit();
}

function login() {
	console.log('login()');
	document.login_form.submit();
}
