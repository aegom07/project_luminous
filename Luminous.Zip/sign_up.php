<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Luminous</title>
  <style>
    header.header#mainHeader {
      background-color: white !important;
    }

    body {
      background-color: #fff;
      color: #000;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      padding: 0;
    }

    .main_wrapper {
      max-width: 900px;
      margin: 40px auto;
      padding: 0 10px;
      box-sizing: border-box;
    }

    .progress {
      display: flex;
      justify-content: space-between;
      margin-bottom: 30px;
    }

    .progress_step {
      flex: 1;
      text-align: center;
      padding: 10px;
      border-bottom: 2px solid #ccc;
      color: #666;
      font-weight: 600;
    }

    .progress_step.step1 {
      border-bottom-color: #000;
      color: #000;
    }

    .join_us_title {
      display: block;
      font-size: 28px;
      font-weight: 700;
      margin-bottom: 24px;
      text-align: center;
      letter-spacing: 1px;
      color: #000;
    }

    .ref {
      font-size: 12px;
      color: #666;
      margin-bottom: 10px;
      font-weight: 600;
    }

    .required {
      color: red;
      margin-right: 4px;
      font-weight: bold;
    }

    .member_form_row {
      margin-bottom: 24px;
    }

    .form {
      display: flex;
      margin-bottom: 20px;
      align-items: center;
    }

    .col1 {
      width: 130px;
      font-weight: 600;
      color: #222;
      margin-right: 15px;
    }

    .col2 input[type="text"],
    .col2 input[type="password"] {
      width: 100%;
      max-width: 600px;
      padding: 14px 16px;
      border: 1.5px solid #ccc;
      border-radius: 0;
      font-size: 16px;
      color: #000;
      box-sizing: border-box;
      transition: border-color 0.3s;
    }

    .col2 input[type="text"]:focus,
    .col2 input[type="password"]:focus {
      border-color: #000;
      outline: none;
    }

    .email .col2 {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .email .col2 input[type="text"] {
      width: 48%;
    }

    .at-symbol {
      font-weight: bold;
      font-size: 16px;
    }

    section {
      margin-top: 40px;
      display: flex;
      justify-content: center;
      gap: 30px;
      padding: 0 10px;
    }

    button {
      border-radius: 0;
      padding: 16px 40px;
      font-size: 18px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s;
      width: 260px;
      border: 1px solid #ccc;
    }

    .button_cancel {
      background-color: #fff;
      color: #000;
    }

    .button_cancel:hover {
      background-color: #eee;
      border-color: #aaa;
      color: #333;
    }

    .button_join {
      background-color: #000;
      color: #fff;
      border: none;
    }

    .button_join:hover {
      background-color: #333;
    }
  </style>
</head>

<body>
  <?php require_once("inc/header.php"); ?>
  <main class="main_wrapper sign_up">
    <div class="progress">
      <div class="progress_step">
        <span class="title">STEP 1</span>
        <span>이용약관 동의</span>
      </div>
      <div class="progress_step step1">
        <span class="title">STEP 2</span>
        <span>회원정보 입력</span>
      </div>
      <div class="progress_step">
        <span class="title">STEP 3</span>
        <span>회원가입 완료</span>
      </div>
    </div>
    <span class="join_us_title">Luminous 회원가입</span>
    <div class="join_box">
      <form name="member_form" method="POST" action="member_insert.php" class="member_form">
        <div class="member_form_col">
          <div class="ref">필수입력</div>
          <div class="member_form_row row1">
            <div class="form id">
              <div class="col1"><span class="required">*</span>아이디</div>
              <div class="col2">
                <input type="text" name="id">
              </div>
            </div>
            <div class="form">
              <div class="col1"><span class="required">*</span>비밀번호</div>
              <div class="col2">
                <input type="password" name="pass">
              </div>
            </div>
            <div class="form">
              <div class="col1"><span class="required">*</span>비밀번호 확인</div>
              <div class="col2">
                <input type="password" name="pass_confirm">
              </div>
            </div>
            <div class="form">
              <div class="col1"><span class="required">*</span>이름</div>
              <div class="col2">
                <input type="text" name="name">
              </div>
            </div>
            <div class="form">
              <div class="col1"><span class="required">*</span>휴대전화</div>
              <div class="col2">
                <input type="text" name="phone">
              </div>
            </div>
          </div>
          <div class="ref">선택입력</div>
          <div class="member_form_row row2">
            <div class="form">
              <div class="col1">생년월일</div>
              <div class="col2">
                <input type="text" name="birth">
              </div>
            </div>
            <div class="form email">
              <div class="col1">이메일</div>
              <div class="col2">
                <input type="text" name="email1">
                <span class="at-symbol">@</span>
                <input type="text" name="email2">
              </div>
            </div>
            </div>
          </div>
        </div>
      </form>
    </div>
    <section>
      <button class="button_cancel">취소</button>
      <button class="button_join" onclick="check_input()">가입</button>
    </section>
  </main>
  <script src="js/member.js"></script>
</body>
<?php require_once("inc/footer.php"); ?>

</html>
